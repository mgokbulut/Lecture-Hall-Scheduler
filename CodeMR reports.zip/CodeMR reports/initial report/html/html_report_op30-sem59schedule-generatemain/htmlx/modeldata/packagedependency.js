var matrix = [[0,0,1,1],[0,0,0,0],[0,0,0,0],[0,0,1,0]]
var packages = [{
"name": " nl.tudelft.unischeduler.schedulegenerate.generator", "color": " #3182bd"
}
,{
"name": " nl.tudelft.unischeduler.schedulegenerate", "color": " #6baed6"
}
,{
"name": " nl.tudelft.unischeduler.schedulegenerate.entities", "color": " #9ecae1"
}
,{
"name": " nl.tudelft.unischeduler.schedulegenerate.api", "color": " #c6dbef"
}
];
