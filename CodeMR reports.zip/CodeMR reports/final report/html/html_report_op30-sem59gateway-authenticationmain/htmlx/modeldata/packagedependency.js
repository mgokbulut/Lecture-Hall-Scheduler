var matrix = [[0,0,0,0,0],[0,0,2,1,1],[0,0,0,2,0],[0,0,0,0,1],[0,0,0,2,0]]
var packages = [{
"name": " nl.tudelft.unischeduler", "color": " #3182bd"
}
,{
"name": " nl.tudelft.unischeduler.sysinteract", "color": " #6baed6"
}
,{
"name": " nl.tudelft.unischeduler.utilentities", "color": " #9ecae1"
}
,{
"name": " nl.tudelft.unischeduler.user", "color": " #c6dbef"
}
,{
"name": " nl.tudelft.unischeduler.authentication", "color": " #e6550d"
}
];
