var matrix = [[0,3,0,0,0],[0,0,0,1,1],[0,0,0,0,0],[0,0,0,0,1],[0,0,0,0,0]]
var packages = [{
"name": " nl.tudelft.unischeduler.scheduleedit.controller", "color": " #3182bd"
}
,{
"name": " nl.tudelft.unischeduler.scheduleedit.core", "color": " #6baed6"
}
,{
"name": " nl.tudelft.unischeduler.scheduleedit", "color": " #9ecae1"
}
,{
"name": " nl.tudelft.unischeduler.scheduleedit.services", "color": " #c6dbef"
}
,{
"name": " nl.tudelft.unischeduler.scheduleedit.exception", "color": " #e6550d"
}
];
