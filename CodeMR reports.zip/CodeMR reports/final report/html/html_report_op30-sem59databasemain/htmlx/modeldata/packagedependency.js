var matrix = [[0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,1,0,0,0],[0,0,0,0,0,0,0,0,0,0,0],[1,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0,1,1,0],[0,0,1,1,0,0,0,0,0,1,0],[0,0,0,0,0,0,0,0,0,0,0],[0,0,1,1,0,0,0,0,0,0,1],[0,0,0,0,0,1,0,0,1,0,1],[0,0,0,0,0,0,0,0,0,0,0]]
var packages = [{
"name": " nl.tudelft.unischeduler.database.exception", "color": " #3182bd"
}
,{
"name": " nl.tudelft.unischeduler.database", "color": " #6baed6"
}
,{
"name": " nl.tudelft.unischeduler.database.lecture", "color": " #9ecae1"
}
,{
"name": " nl.tudelft.unischeduler.database.classroom", "color": " #c6dbef"
}
,{
"name": " nl.tudelft.unischeduler.database.triggers", "color": " #e6550d"
}
,{
"name": " nl.tudelft.unischeduler.database.sicklog", "color": " #fd8d3c"
}
,{
"name": " nl.tudelft.unischeduler.database.usercourse", "color": " #fdae6b"
}
,{
"name": " nl.tudelft.unischeduler.database.course", "color": " #fdd0a2"
}
,{
"name": " nl.tudelft.unischeduler.database.lectureschedule", "color": " #31a354"
}
,{
"name": " nl.tudelft.unischeduler.database.user", "color": " #74c476"
}
,{
"name": " nl.tudelft.unischeduler.database.schedule", "color": " #a1d99b"
}
];
