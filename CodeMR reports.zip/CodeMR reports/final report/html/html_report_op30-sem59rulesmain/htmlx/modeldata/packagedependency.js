var matrix = [[0,1,0,0,1,0],[0,0,0,0,4,0],[1,0,0,1,0,0],[0,0,0,0,1,0],[0,0,0,0,0,0],[2,0,0,2,2,0]]
var packages = [{
"name": " nl.tudelft.unischeduler.rules.core", "color": " #3182bd"
}
,{
"name": " nl.tudelft.unischeduler.rules.services", "color": " #6baed6"
}
,{
"name": " nl.tudelft.unischeduler.rules", "color": " #9ecae1"
}
,{
"name": " nl.tudelft.unischeduler.rules.storing", "color": " #c6dbef"
}
,{
"name": " nl.tudelft.unischeduler.rules.entities", "color": " #e6550d"
}
,{
"name": " nl.tudelft.unischeduler.rules.controllers", "color": " #fd8d3c"
}
];
