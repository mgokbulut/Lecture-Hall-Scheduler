var EQ_workingSetList = [
{name: 'OP30-sem59.database.main', path:'op30-sem59databasemain'},
{name: 'OP30-sem59.discovery-server.main', path:'op30-sem59discovery-servermain'},
{name: 'OP30-sem59.gateway-authentication.main', path:'op30-sem59gateway-authenticationmain'},
{name: 'OP30-sem59.rules.main', path:'op30-sem59rulesmain'},
{name: 'OP30-sem59.schedule-edit.main', path:'op30-sem59schedule-editmain'},
{name: 'OP30-sem59.schedule-generate.main', path:'op30-sem59schedule-generatemain'},
{name: 'OP30-sem59.viewer.main', path:'op30-sem59viewermain'},
];
