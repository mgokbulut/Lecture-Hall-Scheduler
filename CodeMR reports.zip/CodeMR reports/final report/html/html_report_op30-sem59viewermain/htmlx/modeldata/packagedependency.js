var matrix = [[0,0,0,0],[0,0,1,0],[1,0,0,0],[0,0,0,0]]
var packages = [{
"name": " nl.tudelft.unischeduler.viewer.entities", "color": " #3182bd"
}
,{
"name": " nl.tudelft.unischeduler.viewer.controllers", "color": " #6baed6"
}
,{
"name": " nl.tudelft.unischeduler.viewer.services", "color": " #9ecae1"
}
,{
"name": " nl.tudelft.unischeduler.viewer", "color": " #c6dbef"
}
];
